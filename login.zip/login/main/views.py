from django.shortcuts import render, HttpResponseRedirect
# from django.contrib.auth.forms import NameForm
from . forms import NameForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.forms import User
from django.contrib.auth import login, logout, authenticate

# Create your views here.

# signup form

def signup(request):
    if request.method=="POST":
        fd = NameForm(request.POST)
        if fd.is_valid():
            fd.save()
    else:
        fd=NameForm()
    return render(request,'signup.html',{'form':fd})

def user_login(request):
    if request.method=='POST':
        fm = AuthenticationForm(request=request, data=request.POST)
        if fm.is_valid():
            uname=fm.cleaned_data['username']
            upass=fm.cleaned_data['password']
            user = authenticate(username=uname, password=upass)
            if user is not None:
                login(request,user)
                return HttpResponseRedirect('/home/')
    else:
        fm=AuthenticationForm()
    return render(request, 'login.html', {'form':fm})

def home(request):
    return render(request, 'home.html')


def user_logout(requset):
    logout(request)
    return HttpResponseRedirect('/login/')